This folder contains the code for the robot built using URDF and Xacro commands. 
